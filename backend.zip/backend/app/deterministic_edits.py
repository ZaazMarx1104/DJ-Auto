from __future__ import annotations

import random
from typing import List, Tuple

from . import midi_utils
from .models import EditRequest, Note


def _total_beats(req: EditRequest) -> float:
    return midi_utils.total_quarter_beats(req.bars, req.time_signature)


def _clamp_pitch(pitch: int, low: int, high: int) -> int:
    return max(low, min(high, pitch))


def _transpose_notes(
    notes: List[Note], semitones: int, pitch_range: Tuple[int, int]
) -> List[Note]:
    low, high = pitch_range
    out: List[Note] = []
    for n in notes:
        new_pitch = _clamp_pitch(n.pitch + semitones, low, high)
        out.append(
            Note(
                pitch=new_pitch,
                start=n.start,
                duration=n.duration,
                velocity=n.velocity,
                channel=n.channel,
            )
        )
    return out


def _quantize_notes(notes: List[Note], subdivision: str) -> List[Note]:
    out: List[Note] = []
    for n in notes:
        start = midi_utils._quantize_value(float(n.start), subdivision)
        duration = midi_utils._quantize_value(float(n.duration), subdivision)
        min_len = midi_utils.quarter_beat_step("1/32")
        if duration <= 0:
            duration = min_len
        out.append(
            Note(
                pitch=n.pitch,
                start=start,
                duration=duration,
                velocity=n.velocity,
                channel=n.channel,
            )
        )
    return out


def _humanize_notes(req: EditRequest) -> List[Note]:
    seed_val = (
        int(req.tempo * 10)
        + req.bars * 31
        + len(req.notes) * 17
        + sum(n.pitch for n in req.notes)
    )
    rng = random.Random(seed_val)
    total_beats = _total_beats(req)

    out: List[Note] = []
    max_shift = midi_utils.quarter_beat_step("1/32") * 0.5
    for n in req.notes:
        shift = rng.uniform(-max_shift, max_shift)
        new_start = max(0.0, min(n.start + shift, total_beats))
        vel_jitter = rng.randint(-5, 5)
        new_vel = max(1, min(127, n.velocity + vel_jitter))
        out.append(
            Note(
                pitch=n.pitch,
                start=new_start,
                duration=n.duration,
                velocity=new_vel,
                channel=n.channel,
            )
        )
    return out


def _finalize(req: EditRequest, notes: List[Note], warnings: List[str]):
    total_beats = _total_beats(req)
    constrained, extra_warnings = midi_utils._apply_constraints_to_notes(
        notes, req.constraints, total_beats, req.bars
    )
    warnings.extend(extra_warnings)
    return constrained, warnings, True


def try_apply_deterministic_edit(req: EditRequest):
    """Attempt to handle simple text instructions without calling the LLM."""
    instruction = (req.instruction or "").lower().strip()
    if not instruction:
        return req.notes, [], False

    warnings: List[str] = []
    notes = list(req.notes)

    if instruction.startswith("transpose up"):
        semitones = next((int(p) for p in instruction.split() if p.isdigit()), 0)
        if semitones != 0:
            warnings.append(f"deterministic_transpose_up_{semitones}")
            return _finalize(
                req,
                _transpose_notes(notes, semitones, req.constraints.pitch_range),
                warnings,
            )

    if instruction.startswith("transpose down"):
        semitones = next((int(p) for p in instruction.split() if p.isdigit()), 0)
        if semitones != 0:
            warnings.append(f"deterministic_transpose_down_{semitones}")
            return _finalize(
                req,
                _transpose_notes(notes, -semitones, req.constraints.pitch_range),
                warnings,
            )

    if "up a fifth" in instruction:
        warnings.append("deterministic_transpose_up_fifth")
        return _finalize(
            req,
            _transpose_notes(notes, 7, req.constraints.pitch_range),
            warnings,
        )

    if "up an octave" in instruction:
        warnings.append("deterministic_transpose_up_octave")
        return _finalize(
            req,
            _transpose_notes(notes, 12, req.constraints.pitch_range),
            warnings,
        )

    if "quantize to 1/8" in instruction or "quantise to 1/8" in instruction:
        warnings.append("deterministic_quantize_1_8")
        return _finalize(req, _quantize_notes(notes, "1/8"), warnings)

    if "quantize to 1/16" in instruction or "quantise to 1/16" in instruction:
        warnings.append("deterministic_quantize_1_16")
        return _finalize(req, _quantize_notes(notes, "1/16"), warnings)

    if "quantize to 1/4" in instruction or "quantise to 1/4" in instruction:
        warnings.append("deterministic_quantize_1_4")
        return _finalize(req, _quantize_notes(notes, "1/4"), warnings)

    if "humanize" in instruction:
        warnings.append("deterministic_humanize")
        return _finalize(req, _humanize_notes(req), warnings)

    return req.notes, [], False
