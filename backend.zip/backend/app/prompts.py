from __future__ import annotations

import json
from typing import List

from .midi_utils import total_quarter_beats
from .models import EditRequest, GenerateRequest


# ---------------------------------------------------------------------------
# Single-step generate (fallback for vague / non-chord prompts)
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """
You are a MIDI pattern generator and editor.

You MUST output valid JSON ONLY, matching this exact schema:

{
  "notes": [
    { "pitch": int, "start": float, "duration": float, "velocity": int, "channel": int }
  ]
}

CRITICAL: Your entire response must be a single JSON object. Do not include any explanations, comments, markdown formatting, <think> blocks, or text outside the JSON structure.

Rules:
- "start" and "duration" are in quarter-note beats, relative to clip start (0.0).
- All notes must fit within the clip: [0, total_quarter_beats).
- Use only MIDI pitches 0–127 and velocities 1–127.
- Respect role, pitch_range, and max_notes_per_bar that I provide.
- Return ONLY the JSON object, nothing else.
"""


def build_generate_user_prompt(req: GenerateRequest) -> str:
    numerator, denominator = req.time_signature
    total_beats = total_quarter_beats(req.bars, req.time_signature)
    low, high = req.constraints.pitch_range

    return f"""
User request: {req.prompt}

Context:
- Tempo: {req.tempo} BPM
- Time signature: {numerator}/{denominator}
- Bars: {req.bars} (total quarter-note beats: {total_beats})
- Role: {req.role}
- Density: {req.density}
- Register: {req.register}
- Pitch range: {low} to {high}
- Max notes per bar: {req.constraints.max_notes_per_bar}
- Quantize: {req.constraints.quantize}
- Beats per bar: {int(total_beats / req.bars)}

Task:
Interpret the user request musically and generate an appropriate pattern for the given role.

- If the request is vague or stylistic (e.g. "something dreamy", "lofi groove", "dark and tense"),
  use the role, density, register, and tempo as your primary guides and compose freely.
- Use musically appropriate note durations. For whole-bar chords use duration equal to beats per bar. Do not default to duration 1.0.

Always prioritize musical coherence over literal interpretation.
Return a single JSON object with a "notes" array only.
Every note must obey the pitch range and clip bounds.
"""


# ---------------------------------------------------------------------------
# Step 1 — Chord parser
# ---------------------------------------------------------------------------

CHORD_PARSER_SYSTEM_PROMPT = """
You are a music theory expert and chord parser.

Your job is to read a user's prompt and determine whether it contains explicit chord names.
If it does, extract them as an ordered list with full music theory detail.
If it does not, signal that no chords were found.

You MUST output valid JSON ONLY, matching this exact schema:

{
  "has_chords": bool,
  "chords": [
    {
      "bar": int,
      "name": str,
      "root_midi": int,
      "intervals": [int],
      "duration_beats": float
    }
  ]
}

Rules:
- "has_chords" is true only if the prompt contains explicit chord names (e.g. Am7, F6, Em9, Cmaj7, G7).
- If "has_chords" is false, "chords" must be an empty array.
- "bar" is 1-indexed. Assign chords to bars in the order they appear in the prompt.
  If there are fewer chords than bars, repeat the sequence to fill all bars.
- "name" is the chord symbol exactly as you interpret it (e.g. "Am7", "F6").
- "root_midi" is the MIDI note number of the root in the octave that best fits the pitch range provided.
- "intervals" are semitone offsets from the root that define the chord voicing,
  e.g. a major triad is [0, 4, 7], a minor seventh is [0, 3, 7, 10].
  Include all chord tones including extensions (9ths, 11ths, 13ths) where the chord name specifies them.
- "duration_beats" is how long the chord lasts in quarter-note beats. Default to beats_per_bar unless
  the prompt implies otherwise (e.g. two chords per bar).
- Think carefully about each chord's intervals before writing them. Do not guess.
- Return ONLY the JSON object, nothing else.
"""


def build_chord_parser_prompt(req: GenerateRequest) -> str:
    numerator, denominator = req.time_signature
    total_beats = total_quarter_beats(req.bars, req.time_signature)
    beats_per_bar = total_beats / req.bars
    low, high = req.constraints.pitch_range

    return f"""
User prompt: {req.prompt}

Clip context:
- Tempo: {req.tempo} BPM
- Time signature: {numerator}/{denominator}
- Bars: {req.bars} (total quarter-note beats: {total_beats}, beats per bar: {beats_per_bar})
- Pitch range: MIDI {low} to {high}

Task:
Read the prompt and determine if the user is specifying a chord progression.
If yes, extract the chords in order and fill all {req.bars} bars by repeating the sequence if needed.
If no, return has_chords: false.

Return a single JSON object only.
"""


# ---------------------------------------------------------------------------
# Step 2 — Generate from parsed chords
# ---------------------------------------------------------------------------

CHORD_GENERATE_SYSTEM_PROMPT = """
You are a MIDI performance generator.

You will receive a list of chords with their exact notes already worked out for you.
Your job is NOT to figure out music theory — that has already been done.
Your job is to turn the chord map into an expressive, musical MIDI performance.

You MUST output valid JSON ONLY, matching this exact schema:

{
  "notes": [
    { "pitch": int, "start": float, "duration": float, "velocity": int, "channel": int }
  ]
}

Rules:
- "start" and "duration" are in quarter-note beats, relative to clip start (0.0).
- All notes must fit within the clip: [0, total_quarter_beats).
- Use only MIDI pitches 0–127 and velocities 1–127.
- You MUST use exactly the pitches specified in the chord map. Do not add, remove, or alter any chord tones.
- Focus entirely on: timing, velocity, duration, and voice leading between chords.
- Vary velocities naturally across notes in a chord (e.g. root slightly softer, melody note on top slightly louder).
- You may slightly offset note start times within a chord for a strummed or rolled feel if appropriate.
- Respect the role, density, and register provided.
- Return ONLY the JSON object, nothing else.
"""


def build_chord_generate_prompt(req: GenerateRequest, chords: List[dict]) -> str:
    numerator, denominator = req.time_signature
    total_beats = total_quarter_beats(req.bars, req.time_signature)
    beats_per_bar = total_beats / req.bars
    low, high = req.constraints.pitch_range

    # Build a human-readable chord map for the LLM
    chord_map_lines = []
    for chord in chords:
        bar = chord["bar"]
        name = chord["name"]
        root = chord["root_midi"]
        intervals = chord["intervals"]
        pitches = [root + i for i in intervals]
        duration = chord["duration_beats"]
        start = (bar - 1) * beats_per_bar
        chord_map_lines.append(
            f"  Bar {bar} (start={start:.2f}, duration={duration}): {name} → pitches {pitches}"
        )

    chord_map = "\n".join(chord_map_lines)

    return f"""
Chord map (DO NOT alter these pitches):
{chord_map}

Clip context:
- Tempo: {req.tempo} BPM
- Time signature: {numerator}/{denominator}
- Bars: {req.bars} (total quarter-note beats: {total_beats}, beats per bar: {beats_per_bar})
- Role: {req.role}
- Density: {req.density}
- Register: {req.register}
- Pitch range: {low} to {high}
- Max notes per bar: {req.constraints.max_notes_per_bar}
- Quantize: {req.constraints.quantize}

Task:
Render the chord map above as an expressive MIDI performance.
Use exactly the pitches listed for each chord. Make it musical — vary velocities,
consider note durations and timing, and ensure smooth voice leading between chords.
Return a single JSON object with a "notes" array only.
Every note must obey the pitch range and clip bounds.
"""


# ---------------------------------------------------------------------------
# Edit prompt (unchanged)
# ---------------------------------------------------------------------------

_NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def _annotate_note(note_dict: dict, beats_per_bar: float) -> dict:
    """Add human-readable bar number and note name to a note dict."""
    bar = int(note_dict["start"] // beats_per_bar) + 1
    note_name = _NOTE_NAMES[note_dict["pitch"] % 12]
    return {**note_dict, "bar": bar, "note_name": note_name}


def build_edit_user_prompt(req: EditRequest) -> str:
    numerator, denominator = req.time_signature
    total_beats = total_quarter_beats(req.bars, req.time_signature)
    beats_per_bar = total_beats / req.bars
    low, high = req.constraints.pitch_range

    annotated_notes = [
        _annotate_note(
            {
                "pitch": n.pitch,
                "start": n.start,
                "duration": n.duration,
                "velocity": n.velocity,
                "channel": n.channel,
            },
            beats_per_bar,
        )
        for n in req.notes
    ]

    bar_map_lines = [
        f"  Bar {b}: beats {(b - 1) * beats_per_bar:.2f} – {b * beats_per_bar:.2f}"
        for b in range(1, req.bars + 1)
    ]
    bar_map = "\n".join(bar_map_lines)

    return f"""
Edit instruction: {req.instruction}

Current clip context:
- Tempo: {req.tempo} BPM
- Time signature: {numerator}/{denominator}
- Bars: {req.bars} (total quarter-note beats: {total_beats}, beats per bar: {beats_per_bar})
- Role: {req.role}
- Pitch range: {low} to {high}
- Max notes per bar: {req.constraints.max_notes_per_bar}
- Quantize: {req.constraints.quantize}

Bar boundaries:
{bar_map}

Notes grouped by bar — notes sharing the same "start" value form a chord voicing:
{json.dumps(annotated_notes, indent=2)}

Task:
Transform the provided notes according to the edit instruction.
This is a surgical edit of existing MIDI, not a fresh composition.

Rules:
- To change a chord: replace only the notes whose "bar" matches the target bar AND whose "start" matches the chord's position. Do not touch notes in other bars.
- Preserve the start time, duration, velocity, and channel of every note you are NOT changing.
- Do not add or remove notes outside the bars mentioned in the instruction.
- Keep the overall rhythmic layout, note density, and phrase structure intact unless explicitly told otherwise.
- The "bar" and "note_name" fields in the input are for your reference only — do NOT include them in your output.
- Return the FULL updated note list (every note, changed and unchanged).
- Your output must be a single JSON object with a "notes" array and nothing else.
- Each note in the output must have exactly: pitch, start, duration, velocity, channel.
"""