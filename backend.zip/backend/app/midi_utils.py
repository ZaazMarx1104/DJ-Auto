from __future__ import annotations

from typing import Iterable, List, Tuple

from .models import Constraints, EditRequest, GenerateRequest, Note


EPSILON = 1e-9


def total_quarter_beats(bars: int, time_signature: Tuple[int, int]) -> float:
    """Return clip length in quarter-note beats."""
    numerator, denominator = time_signature
    return float(bars * numerator * (4.0 / denominator))


def quarter_beat_step(subdivision: str) -> float:
    """Return the quantization step in quarter-note beats."""
    denom = {"1/4": 4, "1/8": 8, "1/16": 16, "1/32": 32}[subdivision]
    return 4.0 / denom


def _quantize_value(value: float, subdivision: str) -> float:
    """Quantize a quarter-beat value to the nearest subdivision."""
    step = quarter_beat_step(subdivision)
    return round(value / step) * step


def _apply_constraints_to_notes(
    notes: Iterable[Note],
    constraints: Constraints,
    total_beats: float,
    bars: int,
) -> Tuple[List[Note], List[str]]:
    """Quantize, clamp, and enforce basic constraints on a note list."""
    warnings: List[str] = []
    processed: List[Note] = []
    max_notes = constraints.max_notes_per_bar * max(1, int(bars))
    low, high = constraints.pitch_range
    min_duration = quarter_beat_step("1/32")

    for note in notes:
        if len(processed) >= max_notes:
            warnings.append("note_count_reduced_to_fit_constraints")
            break

        pitch = min(max(int(note.pitch), low), high)
        start = max(0.0, _quantize_value(float(note.start), constraints.quantize))
        duration = max(
            _quantize_value(float(note.duration), constraints.quantize),
            min_duration,
        )

        if start >= total_beats - EPSILON:
            continue

        if start + duration > total_beats:
            duration = total_beats - start
            if duration < min_duration:
                continue
            warnings.append("notes_truncated_to_clip_length")

        velocity = min(max(int(note.velocity), 1), 127)
        channel = min(max(int(note.channel), 0), 15)

        processed.append(
            Note(
                pitch=pitch,
                start=start,
                duration=duration,
                velocity=velocity,
                channel=channel,
            )
        )

    if constraints.max_polyphony > 0 and processed:
        processed.sort(key=lambda n: (n.start, -n.duration))
        filtered: List[Note] = []
        current_time = None
        stack: List[Note] = []
        for n in processed:
            if current_time is None or abs(n.start - current_time) < 1e-6:
                current_time = n.start
                stack.append(n)
            else:
                stack.sort(key=lambda x: x.velocity, reverse=True)
                filtered.extend(stack[: constraints.max_polyphony])
                stack = [n]
                current_time = n.start
        if stack:
            stack.sort(key=lambda x: x.velocity, reverse=True)
            filtered.extend(stack[: constraints.max_polyphony])
        processed = filtered

    return processed, warnings


def post_process_generated(
    req: GenerateRequest, raw_payload: dict
) -> Tuple[List[Note], List[str]]:
    """Convert the raw LLM payload into validated Note objects and apply constraints."""
    total_beats = total_quarter_beats(req.bars, req.time_signature)
    raw_notes = raw_payload.get("notes", [])

    _NOTE_FIELDS = {"pitch", "start", "duration", "velocity", "channel"}

    notes: List[Note] = []
    for item in raw_notes:
        try:
            notes.append(Note(**{k: v for k, v in item.items() if k in _NOTE_FIELDS}))
        except Exception:
            continue

    notes, warnings = _apply_constraints_to_notes(
        notes, req.constraints, total_beats, req.bars
    )
    if not notes:
        warnings.append("empty_notes_after_post_process")
    return notes, warnings


def post_process_edited(
    req: EditRequest, raw_payload: dict
) -> Tuple[List[Note], List[str]]:
    """Same as post_process_generated but for edit responses."""
    total_beats = total_quarter_beats(req.bars, req.time_signature)
    raw_notes = raw_payload.get("notes", [])

    _NOTE_FIELDS = {"pitch", "start", "duration", "velocity", "channel"}

    notes: List[Note] = []
    for item in raw_notes:
        try:
            notes.append(Note(**{k: v for k, v in item.items() if k in _NOTE_FIELDS}))
        except Exception:
            continue

    notes, warnings = _apply_constraints_to_notes(
        notes, req.constraints, total_beats, req.bars
    )
    if not notes:
        warnings.append("empty_notes_after_post_process")
    return notes, warnings