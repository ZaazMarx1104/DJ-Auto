from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Literal, Optional, Tuple


SUPPORTED_QUANTIZE_VALUES = ("1/4", "1/8", "1/16", "1/32")


class ValidationError(ValueError):
    """Raised when a request payload fails validation."""


@dataclass
class Constraints:
    """Hard limits and quantization settings applied after generation/editing."""

    max_notes_per_bar: int = 12
    pitch_range: Tuple[int, int] = (36, 96)
    quantize: Literal["1/4", "1/8", "1/16", "1/32"] = "1/32"
    max_polyphony: int = 4

    def __post_init__(self) -> None:
        self.max_notes_per_bar = int(self.max_notes_per_bar)
        self.max_polyphony = int(self.max_polyphony)
        if self.max_notes_per_bar < 1:
            raise ValidationError("constraints.max_notes_per_bar must be at least 1")
        if self.max_polyphony < 1:
            raise ValidationError("constraints.max_polyphony must be at least 1")

        try:
            low = int(self.pitch_range[0])
            high = int(self.pitch_range[1])
        except (TypeError, IndexError, ValueError) as exc:
            raise ValidationError(
                "constraints.pitch_range must be a pair of integers"
            ) from exc
        if not (0 <= low <= 127 and 0 <= high <= 127 and low <= high):
            raise ValidationError(
                "constraints.pitch_range must be within 0..127 and low <= high"
            )
        self.pitch_range = (low, high)

        if self.quantize not in SUPPORTED_QUANTIZE_VALUES:
            allowed = ", ".join(SUPPORTED_QUANTIZE_VALUES)
            raise ValidationError(
                f"constraints.quantize must be one of: {allowed}"
            )


@dataclass
class Note:
    """Single MIDI note event on a beat grid."""

    pitch: int
    start: float
    duration: float
    velocity: int
    channel: int = 0

    def __post_init__(self) -> None:
        self.pitch = int(self.pitch)
        self.start = float(self.start)
        self.duration = float(self.duration)
        self.velocity = int(self.velocity)
        self.channel = int(self.channel)


Role = Literal["bass", "chords", "lead", "drums"]
Density = Literal["sparse", "medium", "dense"]
Register = Literal["low", "mid", "high"]


@dataclass
class GenerateRequest:
    """Request body for generating a new MIDI pattern from text."""

    prompt: str
    tempo: float
    time_signature: Tuple[int, int]
    bars: int
    role: Role = "chords"
    density: Density = "medium"
    register: Register = "mid"
    constraints: Constraints = field(default_factory=Constraints)
    seed: Optional[int] = None

    def __post_init__(self) -> None:
        self.prompt = str(self.prompt).strip()
        if not self.prompt:
            raise ValidationError("prompt is required")
        self.tempo = _validate_tempo(self.tempo)
        self.time_signature = _validate_time_signature(self.time_signature)
        self.bars = _validate_bars(self.bars)
        self.role = _validate_enum("role", self.role, ("bass", "chords", "lead", "drums"))
        self.density = _validate_enum("density", self.density, ("sparse", "medium", "dense"))
        self.register = _validate_enum("register", self.register, ("low", "mid", "high"))
        if self.seed is not None:
            self.seed = int(self.seed)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GenerateRequest":
        constraints = _build_constraints(data.get("constraints"))
        ts = data.get("time_signature", [4, 4])
        return cls(
            prompt=data["prompt"],
            tempo=data["tempo"],
            time_signature=(ts[0], ts[1]),
            bars=data["bars"],
            role=data.get("role", "chords"),
            density=data.get("density", "medium"),
            register=data.get("register", "mid"),
            constraints=constraints,
            seed=data.get("seed"),
        )


@dataclass
class EditRequest:
    """Request body for editing an existing pattern using text instructions."""

    instruction: str
    tempo: float
    time_signature: Tuple[int, int]
    bars: int
    role: Role = "chords"
    constraints: Constraints = field(default_factory=Constraints)
    notes: List[Note] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.instruction = str(self.instruction).strip()
        if not self.instruction:
            raise ValidationError("instruction is required")
        self.tempo = _validate_tempo(self.tempo)
        self.time_signature = _validate_time_signature(self.time_signature)
        self.bars = _validate_bars(self.bars)
        self.role = _validate_enum("role", self.role, ("bass", "chords", "lead", "drums"))

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EditRequest":
        constraints = _build_constraints(data.get("constraints"))
        ts = data.get("time_signature", [4, 4])
        raw_notes = data.get("notes") or []
        if not isinstance(raw_notes, list):
            raise ValidationError("notes must be an array")

        notes: List[Note] = []
        for idx, item in enumerate(raw_notes):
            if not isinstance(item, dict):
                raise ValidationError(f"notes[{idx}] must be an object")
            try:
                notes.append(
                    Note(
                        pitch=item["pitch"],
                        start=item["start"],
                        duration=item["duration"],
                        velocity=item["velocity"],
                        channel=item.get("channel", 0),
                    )
                )
            except KeyError as exc:
                raise ValidationError(
                    f"notes[{idx}] is missing required field: {exc.args[0]}"
                ) from exc
            except (TypeError, ValueError) as exc:
                raise ValidationError(f"notes[{idx}] is invalid: {exc}") from exc

        return cls(
            instruction=data["instruction"],
            tempo=data["tempo"],
            time_signature=(ts[0], ts[1]),
            bars=data["bars"],
            role=data.get("role", "chords"),
            constraints=constraints,
            notes=notes,
        )


@dataclass
class Meta:
    """Metadata attached to responses for UX and debugging."""

    request_id: str = ""
    warnings: List[str] = field(default_factory=list)
    model: Optional[str] = None
    latency_ms: Optional[int] = None


@dataclass
class MidiResponse:
    """Response body containing concrete MIDI notes and optional metadata."""

    notes: List[Note]
    meta: Meta = field(default_factory=Meta)


def _validate_tempo(value: Any) -> float:
    tempo = float(value)
    if tempo <= 0:
        raise ValidationError("tempo must be greater than 0")
    return tempo


def _validate_time_signature(value: Any) -> Tuple[int, int]:
    try:
        numerator = int(value[0])
        denominator = int(value[1])
    except (TypeError, IndexError, ValueError) as exc:
        raise ValidationError("time_signature must be a pair like [4, 4]") from exc
    if numerator < 1:
        raise ValidationError("time_signature numerator must be at least 1")
    if denominator not in (1, 2, 4, 8, 16, 32):
        raise ValidationError(
            "time_signature denominator must be one of 1, 2, 4, 8, 16, 32"
        )
    return (numerator, denominator)


def _validate_bars(value: Any) -> int:
    bars = int(value)
    if bars < 1:
        raise ValidationError("bars must be at least 1")
    return bars


def _validate_enum(name: str, value: Any, allowed: Tuple[str, ...]) -> str:
    normalized = str(value)
    if normalized not in allowed:
        raise ValidationError(f"{name} must be one of: {', '.join(allowed)}")
    return normalized


def _build_constraints(value: Any) -> Constraints:
    if value is None:
        return Constraints()
    if not isinstance(value, dict):
        raise ValidationError("constraints must be an object")
    try:
        return Constraints(**value)
    except TypeError as exc:
        raise ValidationError(f"constraints contains unsupported fields: {exc}") from exc


def midi_response_to_dict(response: MidiResponse) -> Dict[str, Any]:
    """Serialize MidiResponse to a JSON-serializable dict."""
    return {
        "notes": [asdict(n) for n in response.notes],
        "meta": asdict(response.meta),
    }
