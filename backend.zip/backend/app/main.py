from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional
from uuid import uuid4

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from . import deterministic_edits, llm_client, midi_utils
from .config import get_settings
from .models import EditRequest, GenerateRequest, Meta, MidiResponse, ValidationError, midi_response_to_dict


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
settings = get_settings()


@asynccontextmanager
async def lifespan(app: Starlette):
    await llm_client.startup()
    try:
        yield
    finally:
        await llm_client.shutdown()


def _build_meta(
    request_id: str,
    warnings: Optional[List[str]] = None,
    model: Optional[str] = None,
    latency_ms: Optional[int] = None,
) -> Dict[str, Any]:
    meta = Meta(
        request_id=request_id,
        warnings=warnings or [],
        model=model,
        latency_ms=latency_ms,
    )
    return {
        "request_id": meta.request_id,
        "warnings": meta.warnings,
        "model": meta.model,
        "latency_ms": meta.latency_ms,
    }


def _error_response(
    request_id: str,
    code: str,
    message: str,
    status_code: int,
    retry_after_seconds: Optional[int] = None,
    model: Optional[str] = None,
    warnings: Optional[List[str]] = None,
    latency_ms: Optional[int] = None,
) -> JSONResponse:
    body: Dict[str, Any] = {
        "error": {
            "code": code,
            "message": message,
            "retry_after_seconds": retry_after_seconds,
        },
        "meta": _build_meta(
            request_id=request_id,
            warnings=warnings,
            model=model,
            latency_ms=latency_ms,
        ),
    }
    return JSONResponse(body, status_code=status_code)



async def _generate_with_retry(req: GenerateRequest) -> tuple[list, list[str]]:
    warnings: List[str] = []

    # Step 1: try chord parser
    try:
        chord_payload = await llm_client.parse_chords(req)
        has_chords = chord_payload.get("has_chords", False)
        chords = chord_payload.get("chords", [])
    except Exception:
        logger.warning("Chord parser failed, falling back to single-step generate")
        has_chords = False
        chords = []

    # Step 2a: chord path
    if has_chords and chords:
        raw_payload = await llm_client.generate_from_chords(req, chords)
        notes, post_warnings = midi_utils.post_process_generated(req, raw_payload)
        warnings.extend(post_warnings)
        if notes:
            return notes, warnings
        logger.warning("Chord generate returned empty notes, falling back to single-step")

    # Step 2b: single-step path (vague prompts or chord path failed)
    raw_payload = await llm_client.generate_notes(req)
    notes, post_warnings = midi_utils.post_process_generated(req, raw_payload)
    warnings.extend(post_warnings)
    if notes:
        return notes, warnings

    # Final retry
    logger.warning("Single-step generate returned empty notes, retrying strict")
    retry_payload = await llm_client.generate_notes_strict(req)
    retry_notes, retry_warnings = midi_utils.post_process_generated(req, retry_payload)
    return retry_notes, warnings + retry_warnings + ["llm_empty_notes_retry"]


async def _edit_with_retry(req: EditRequest) -> tuple[list, list[str]]:
    raw_payload = await llm_client.edit_notes(req)
    notes, warnings = midi_utils.post_process_edited(req, raw_payload)
    if notes:
        return notes, warnings

    logger.warning("edit_midi returned empty notes after post-process; retrying strict")
    retry_payload = await llm_client.edit_notes_strict(req)
    retry_notes, retry_warnings = midi_utils.post_process_edited(req, retry_payload)
    return retry_notes, warnings + retry_warnings + ["llm_empty_notes_retry"]


async def health(request: Request) -> JSONResponse:
    key_present = bool(settings.groq_api_key)
    return JSONResponse(
        {"status": "ok", "framework": "starlette", "llm_provider": "groq", "llm_key_present": key_present}
    )



async def generate_midi(request: Request) -> JSONResponse:
    request_id = str(uuid4())
    t0 = time.time()

    try:
        data = await request.json()
    except Exception:
        return _error_response(
            request_id=request_id,
            code="INVALID_JSON",
            message="Invalid JSON body",
            status_code=400,
            latency_ms=int((time.time() - t0) * 1000),
        )

    client_request_id = data.get("client_request_id")
    if isinstance(client_request_id, str) and client_request_id:
        request_id = client_request_id

    try:
        req = GenerateRequest.from_dict(data)
        logger.info("Received generate request, prompt: %s", req.prompt)
    except KeyError as exc:
        return _error_response(
            request_id=request_id,
            code="VALIDATION_ERROR",
            message=f"Missing required field: {exc.args[0]}",
            status_code=400,
            latency_ms=int((time.time() - t0) * 1000),
        )
    except (ValidationError, TypeError, ValueError) as exc:
        return _error_response(
            request_id=request_id,
            code="VALIDATION_ERROR",
            message=str(exc),
            status_code=400,
            latency_ms=int((time.time() - t0) * 1000),
        )

    warnings: List[str] = []

    try:
        notes, warnings = await _generate_with_retry(req)
        if not notes:
            raise llm_client.GroqError(
                code="BAD_LLM_RESPONSE",
                message="LLM returned no usable notes after retry.",
                status_code=502,
                retry_after_seconds=None,
            )
        model = settings.llm_model
    except llm_client.GroqError as exc:
        logger.warning("generate_midi LLM failed: %s", exc.message)
        return _error_response(
            request_id=request_id,
            code=exc.code,
            message=exc.message,
            status_code=exc.status_code,
            retry_after_seconds=exc.retry_after_seconds,
            latency_ms=int((time.time() - t0) * 1000),
        )
    except Exception as exc:
        logger.exception("generate_midi unexpected failure")
        return _error_response(
            request_id=request_id,
            code="INTERNAL_ERROR",
            message="An unexpected error occurred.",
            status_code=500,
            latency_ms=int((time.time() - t0) * 1000),
        )

    latency_ms = int((time.time() - t0) * 1000)
    meta = Meta(
        request_id=request_id,
        warnings=warnings,
        model=model,
        latency_ms=latency_ms,
    )
    response = MidiResponse(notes=notes, meta=meta)
    return JSONResponse(midi_response_to_dict(response))


async def edit_midi(request: Request) -> JSONResponse:
    request_id = str(uuid4())
    t0 = time.time()

    try:
        data = await request.json()
    except Exception:
        return _error_response(
            request_id=request_id,
            code="INVALID_JSON",
            message="Invalid JSON body",
            status_code=400,
            latency_ms=int((time.time() - t0) * 1000),
        )

    client_request_id = data.get("client_request_id")
    if isinstance(client_request_id, str) and client_request_id:
        request_id = client_request_id

    try:
        req = EditRequest.from_dict(data)
    except KeyError as exc:
        return _error_response(
            request_id=request_id,
            code="VALIDATION_ERROR",
            message=f"Missing required field: {exc.args[0]}",
            status_code=400,
            latency_ms=int((time.time() - t0) * 1000),
        )
    except (ValidationError, TypeError, ValueError) as exc:
        return _error_response(
            request_id=request_id,
            code="VALIDATION_ERROR",
            message=str(exc),
            status_code=400,
            latency_ms=int((time.time() - t0) * 1000),
        )

    warnings: List[str] = []

    det_notes, det_warnings, handled = deterministic_edits.try_apply_deterministic_edit(req)
    if handled:
        notes = det_notes
        warnings.extend(det_warnings)
        model = None
    else:
        try:
            notes, post_warnings = await _edit_with_retry(req)
            if not notes:
                raise llm_client.GroqError(
                    code="BAD_LLM_RESPONSE",
                    message="LLM returned no usable edited notes after retry.",
                    status_code=502,
                    retry_after_seconds=None,
                )
            warnings.extend(post_warnings)
            model = settings.llm_model
        except llm_client.GroqError as exc:
            logger.warning("edit_midi LLM failed: %s", exc.message)
            return _error_response(
                request_id=request_id,
                code=exc.code,
                message=exc.message,
                status_code=exc.status_code,
                retry_after_seconds=exc.retry_after_seconds,
                warnings=warnings,
                latency_ms=int((time.time() - t0) * 1000),
            )
        except Exception as exc:
            logger.exception("edit_midi unexpected failure")
            return _error_response(
                request_id=request_id,
                code="INTERNAL_ERROR",
                message="An unexpected error occurred.",
                status_code=500,
                warnings=warnings,
                latency_ms=int((time.time() - t0) * 1000),
            )

    latency_ms = int((time.time() - t0) * 1000)
    meta = Meta(
        request_id=request_id,
        warnings=warnings,
        model=model,
        latency_ms=latency_ms,
    )
    response = MidiResponse(notes=notes, meta=meta)
    return JSONResponse(midi_response_to_dict(response))



routes = [
    Route("/health", health),
    Route("/generate_midi", generate_midi, methods=["POST"]),
    Route("/edit_midi", edit_midi, methods=["POST"]),
]

app = Starlette(debug=False, routes=routes, lifespan=lifespan)