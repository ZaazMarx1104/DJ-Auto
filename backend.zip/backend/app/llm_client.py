from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, Optional

import httpx

from .config import get_settings
from .models import EditRequest, GenerateRequest
from .prompts import (
    SYSTEM_PROMPT,
    CHORD_PARSER_SYSTEM_PROMPT,
    CHORD_GENERATE_SYSTEM_PROMPT,
    build_edit_user_prompt,
    build_generate_user_prompt,
    build_chord_parser_prompt,
    build_chord_generate_prompt,
)

logger = logging.getLogger(__name__)


_settings = get_settings()
_client: httpx.AsyncClient | None = None
STRICT_JSON_RETRY_SUFFIX = """

Retry instruction:
- Return exactly one valid JSON object.
- The top-level object MUST contain a "notes" key whose value is an array.
- Do not include markdown, prose, explanations, code fences, or trailing text.
- Ensure every note object includes pitch, start, duration, velocity, and channel.
""".strip()


class GroqError(RuntimeError):
    def __init__(self, code, message, status_code, retry_after_seconds=None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.retry_after_seconds = retry_after_seconds


async def startup() -> None:
    global _client
    if _client is None:
        if not _settings.groq_api_key:
            return
        _client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {_settings.groq_api_key}",
                "Content-Type": "application/json",
            },
            timeout=60.0,
        )


async def shutdown() -> None:
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None


def _get_client() -> httpx.AsyncClient:
    if _client is None:
        if not _settings.groq_api_key:
            raise GroqError("MISSING_API_KEY", "GROQ_API_KEY is not set.", 400)
        raise GroqError("CLIENT_NOT_READY", "LLM client is not initialized yet.", 503)
    return _client


def _extract_json_from_content(content: str) -> Dict[str, Any]:
    # Strip Qwen3 thinking blocks before scanning for JSON
    content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL).strip()

    decoder = json.JSONDecoder()
    try:
        parsed = json.loads(content)
        if isinstance(parsed, list):
            return {"notes": parsed}
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass

    for idx, char in enumerate(content):
        if char not in "[{":
            continue
        try:
            parsed, _ = decoder.raw_decode(content[idx:])
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, list):
            return {"notes": parsed}
        if isinstance(parsed, dict):
            return parsed

    raise ValueError("Could not extract valid JSON from content")


def _parse_llm_payload(content: str) -> Dict[str, Any]:
    try:
        data = _extract_json_from_content(content)
    except Exception as exc:
        raise GroqError("BAD_LLM_RESPONSE", f"Failed to parse LLM JSON: {exc}", 502) from exc
    if "notes" not in data or not isinstance(data["notes"], list):
        raise GroqError("BAD_LLM_RESPONSE", "LLM response missing 'notes' array.", 502)
    return data


async def _call_llm_once(
    system: str,
    user: str,
    temperature: float,
    allow_thinking: bool = False,
) -> Dict[str, Any]:
    client = _get_client()
    request_body: Dict[str, Any] = {
        "model": _settings.llm_model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": temperature,
    }
    if not allow_thinking:
        request_body["reasoning_effort"] = "none"

    try:
        resp = await client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            json=request_body,
        )
    except httpx.HTTPError as exc:
        raise GroqError("NETWORK_ERROR", f"Network error: {exc}", 502) from exc

    status = resp.status_code
    if status != 200:
        retry_after_header = resp.headers.get("Retry-After")
        retry_after: Optional[int] = None
        if retry_after_header is not None:
            try:
                retry_after = int(retry_after_header)
            except ValueError:
                retry_after = None

        try:
            error_payload = resp.json()
        except Exception:
            error_payload = resp.text

        if status == 401:
            raise GroqError("INVALID_API_KEY", f"401 Unauthorized: {error_payload}", 401)
        if status == 429:
            raise GroqError("OUT_OF_FREE_QUOTA", f"429 quota error: {error_payload}", 429, retry_after)
        raise GroqError("GROQ_API_ERROR", f"Groq API error {status}: {error_payload}", status, retry_after)

    payload = resp.json()
    choices = payload.get("choices") or []
    if not choices:
        raise GroqError("BAD_LLM_RESPONSE", "LLM response contained no choices.", 502)
    content = choices[0]["message"].get("content")
    if not content:
        raise GroqError("BAD_LLM_RESPONSE", "LLM returned empty content.", 502)

    logger.debug("Received LLM response:\n%s", content)
    return {"content": content}


async def _call_llm(system: str, user: str) -> Dict[str, Any]:
    first_payload = await _call_llm_once(system, user, temperature=0.6)
    first_content = first_payload["content"]

    try:
        return _parse_llm_payload(first_content)
    except GroqError as first_exc:
        if first_exc.code != "BAD_LLM_RESPONSE":
            raise
        logger.warning("Retrying LLM request with strict JSON instruction after malformed response")
        retry_user = f"{user}\n\n{STRICT_JSON_RETRY_SUFFIX}"
        retry_payload = await _call_llm_once(system, retry_user, temperature=0.2)
        return _parse_llm_payload(retry_payload["content"])


async def generate_notes(req: GenerateRequest) -> Dict[str, Any]:
    user = build_generate_user_prompt(req)
    return await _call_llm(SYSTEM_PROMPT, user)


async def edit_notes(req: EditRequest) -> Dict[str, Any]:
    user = build_edit_user_prompt(req)
    return await _call_llm(SYSTEM_PROMPT, user)


async def generate_notes_strict(req: GenerateRequest) -> Dict[str, Any]:
    user = f"{build_generate_user_prompt(req)}\n\n{STRICT_JSON_RETRY_SUFFIX}"
    payload = await _call_llm_once(SYSTEM_PROMPT, user, temperature=0.2)
    return _parse_llm_payload(payload["content"])


async def parse_chords(req: GenerateRequest) -> Dict[str, Any]:
    """Step 1: Parse the user prompt into a structured chord list.
    Uses allow_thinking=True so the model can reason about music theory freely."""
    user = build_chord_parser_prompt(req)
    payload = await _call_llm_once(
        CHORD_PARSER_SYSTEM_PROMPT, user, temperature=0.1, allow_thinking=True
    )
    try:
        data = _extract_json_from_content(payload["content"])
    except Exception as exc:
        raise GroqError("BAD_LLM_RESPONSE", f"Chord parser returned invalid JSON: {exc}", 502) from exc
    if "has_chords" not in data:
        raise GroqError("BAD_LLM_RESPONSE", "Chord parser response missing 'has_chords' field.", 502)
    logger.info("Chord parser result: has_chords=%s, chord_count=%s", data["has_chords"], len(data.get("chords", [])))
    return data


async def generate_from_chords(req: GenerateRequest, chords: list) -> Dict[str, Any]:
    """Step 2: Render a chord map as an expressive MIDI performance.
    Thinking disabled — the chord map is already solved, just output JSON."""
    user = build_chord_generate_prompt(req, chords)
    return await _call_llm(CHORD_GENERATE_SYSTEM_PROMPT, user)


async def edit_notes_strict(req: EditRequest) -> Dict[str, Any]:
    user = f"{build_edit_user_prompt(req)}\n\n{STRICT_JSON_RETRY_SUFFIX}"
    payload = await _call_llm_once(SYSTEM_PROMPT, user, temperature=0.2)
    return _parse_llm_payload(payload["content"])